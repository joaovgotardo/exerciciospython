def informacoes(p_nome, p_animal):
    try:
        print(p_nome + ' ' + p_animal)
        return "Ok na operação"
    except:
        return "Deu erro"

def nome_informacoes():
    v_nome = input("Qual o seu nome?")
    v_animal = input("Qual o seu animal preferido?")
    informacoes(v_nome, v_animal)

nome_informacoes()
