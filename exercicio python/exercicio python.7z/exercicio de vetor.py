v_valores = []
v_inicio = 100

while v_inicio <= 120:
    v_valores.append(v_inicio)
    v_inicio = v_inicio + 1

print(v_valores)
print(v_valores[16 - 1])
